---
name: action-planner
description: >
  Step 6 of 6 in the ambursaData Pipeline. Builds the final prioritised action
  plan from all previous outputs. Answers all 5 audience questions. Assigns
  owners, timeframes, and success metrics to every recommendation. Verifies
  the complete pipeline. Closes with a plain-English executive brief the
  audience can share and act on. Saves as action_plan.md.
---

# Action Planner

This is the last step.
Everything built before this — the data brief, the queries, the findings,
the charts, the story — was preparation.
This step is the destination.
An action plan that sits in a folder is worthless.
An action plan that lands on the right desk, in language the right person can act on,
at the right level of priority and specificity,
is the most valuable thing a data analyst can deliver.
Your job now is to take everything you have built
and answer the only questions that matter:
What do we do? Who does it? By when? How will we know it worked?
Save as `action_plan.md`.

---

## Prerequisites

```
READ FIRST: data_brief.md      → audience, decision this analysis was meant to inform
READ SECOND: findings.md       → top findings, hidden opportunities, open questions
READ THIRD: data_story.md      → Part 5 (what we should do) and Part 6 (potential impact)
READ FOURTH: dashboard_spec.md → charts and dashboards built, for reference links
```

---

## The 5 Questions Every Action Plan Must Answer

```
THE AUDIENCE MUST BE ABLE TO ANSWER ALL 5 BEFORE YOU CLOSE:

  1. What is happening?
     [Answered in the Executive Summary — 1 sentence]

  2. Why is it happening?
     [Answered in the Key Findings recap — 1–2 sentences]

  3. Why should I care?
     [Answered in the Business Impact section — quantified if possible]

  4. What opportunity am I missing?
     [Answered in the Strategic Opportunities section]

  5. What should I do next?
     [Answered in the Prioritised Actions table — specific, owned, timed]

If any of the five cannot be answered, the plan is incomplete.
Go back to the relevant output file and address the gap before saving.
```

---

## Step 1 — The Executive Summary

```
PURPOSE: One paragraph. The whole story in 5 sentences.
         A busy decision-maker reads only this. They must leave knowing
         what is happening, why it matters, and what the top action is.

STRUCTURE:
  Sentence 1: The most important finding (with the key number).
  Sentence 2: Why it matters (the business consequence).
  Sentence 3: The hidden opportunity (or the second finding).
  Sentence 4: The single most important action.
  Sentence 5: What success looks like in [timeframe].

RULES:
  → No jargon. No methodology. No apologies for data quality.
  → If you mention a percentage, give it context.
  → The executive should be able to forward this paragraph to their team.

TEMPLATE:
  "[Most important finding in plain English, with key number].
   This matters because [business consequence].
   The data also reveals [hidden opportunity or second finding].
   The most important action we can take is [specific action].
   If we act by [timeframe], we expect to [outcome]."

EXAMPLE:
  "Revenue has fallen 23% in the North West region over the past six months,
   driven by the loss of a single key account that represented 31% of regional sales.
   This matters because, without replacement revenue, the region will miss
   its annual target by £1.4 million.
   The data also reveals that the Mid-Market segment in the same region
   is growing at 18% — suggesting a replacement pipeline already exists.
   The most important action is to redirect the regional sales team's focus
   to Mid-Market outreach in the North West, starting this quarter.
   If we close two new Mid-Market accounts by the end of Q2,
   we can recover approximately half the lost revenue within six months."
```

---

## Step 2 — Key Findings Recap

```
PURPOSE: 3 bullet points. The top 3 findings from findings.md,
         each in one clear sentence with the key number.

RULES:
  → State the finding, not the topic.
  → Include the key number with context.
  → No more than 25 words per bullet.

TEMPLATE:
  • [Finding 1 — one sentence, key number with context]
  • [Finding 2 — one sentence, key number with context]
  • [Finding 3 — one sentence, key number with context]
```

---

## Step 3 — Business Impact Assessment

```
PURPOSE: Translate findings into financial, operational, or risk terms.
         This is where analysis becomes business intelligence.

RULES:
  → Quantify where the data supports it. Show the calculation.
  → Where quantification is not possible, describe direction and scale.
  → Be direct about risk. "If this continues..." is a valid framing.
  → Separate confirmed impact from projected impact.

THE IMPACT FRAMEWORK:
  For each top finding, complete this:

  FINDING: [title]
  Current state:   [what the data shows now]
  Trend:           [direction — improving, worsening, stable, unknown]
  Impact if        [the finding continues unchanged]:
    Revenue:       [estimate or direction]
    Cost:          [estimate or direction]
    Customers:     [estimate or direction]
    Risk:          [describe the risk]
  Confidence:      HIGH / MEDIUM / LOW [with reason]

CALCULATION TRANSPARENCY RULE:
  If you write "this could cost approximately £X", show the maths:
  "£X = [base metric] × [assumption] × [timeframe]
   Assumption: [what you assumed and why]
   Confidence: [HIGH if data-based, MEDIUM if estimated, LOW if speculative]"
```

---

## Step 4 — Strategic Opportunities

```
PURPOSE: Convert hidden opportunities from findings.md
         into decision-ready proposals.

RULES:
  → Base every opportunity on a specific finding.
  → Distinguish evidence from hypothesis.
  → Estimate impact only where the data supports it.
  → Each opportunity needs a next action to test or capture it.

OPPORTUNITY PROPOSAL FORMAT:

  ## Opportunity [N]: [Title]

  **What the data shows:**
  [The specific finding that reveals this opportunity — with the number]

  **What this means:**
  [Why this is an opportunity, in plain English]

  **What would need to be true:**
  [The conditions or assumptions this opportunity rests on]

  **How to test it:**
  [The smallest action that would confirm or deny the opportunity]

  **Potential impact if confirmed:**
  [Direction and scale — quantified if possible, described if not]

  **Decision needed:**
  [What decision the leadership team needs to make to pursue this]
```

---

## Step 5 — Prioritised Actions Table

```
PURPOSE: The main deliverable. A prioritised, owned, timed list
         of specific actions. This table must be actionable on Monday morning.

PRIORITISATION FRAMEWORK:
  TIER 1 (Do now — high impact, feasible immediately):
    Things that could affect the next 30 days of results.
    Usually 1–3 actions.

  TIER 2 (Do soon — high impact, requires planning):
    Things that need setup, approval, or cross-team coordination.
    Usually 2–4 actions.

  TIER 3 (Investigate — uncertain impact, needs more data):
    Things that the analysis revealed but cannot yet be quantified.
    These are "run a test" or "investigate further" actions.
    Usually 1–3 actions.

RULE: "Investigate X" is only a valid Tier 3 action.
      Tier 1 and Tier 2 must be specific: who does what, by when.

TABLE FORMAT:
  | Priority | Action | Reason | Owner | Deadline | Success Metric |
  |----------|--------|--------|-------|----------|----------------|
  | TIER 1   |        |        |       |          |                |
  |          |        |        |       |          |                |
  | TIER 2   |        |        |       |          |                |
  |          |        |        |       |          |                |
  | TIER 3   |        |        |       |          |                |
  |          |        |        |       |          |                |

COLUMN DEFINITIONS:
  Action:         Specific, verb-first. "Review pricing for X with Sales team."
  Reason:         One clause linking the action to a finding.
  Owner:          The person or team responsible.
                  If unknown, write [assign] — do not leave blank.
  Deadline:       Specific date or milestone. "End of Q2" is acceptable.
                  "ASAP" is not.
  Success Metric: What specifically will be different when this is done?
                  Not "improve" — "increase by X%" or "reduce from X to Y".
```

---

## Step 6 — Success Metrics Dashboard

```
PURPOSE: Define what success looks like in 30, 60, and 90 days.
         This becomes the KPI check-in agenda.

FORMAT:
  FOR EACH TIER 1 AND TIER 2 ACTION:

  Action: [name]
  Metric: [what will be measured]
  Baseline (now): [current value from the data]

  30-day check: [what should be true in 30 days]
  60-day check: [what should be true in 60 days]
  90-day check: [what should be true in 90 days — the "success" threshold]

  Data source: [which table / dashboard will show this metric]
  Review owner: [who checks this at each interval]

RULE: The 90-day check should be specific enough that any stakeholder
      can answer YES or NO without ambiguity.
      "Improve customer retention" is not a 90-day check.
      "Customer retention rate above 78% for two consecutive months" is.
```

---

## Step 7 — Open Questions and Next Analysis

```
PURPOSE: Be honest about what this analysis could not answer.
         Name what should be investigated next, and why.

FORMAT:
  OPEN QUESTION 1: [question]
  Why it matters:  [what decision it would inform]
  Data needed:     [what would need to be collected or joined]
  Recommended by:  [timeframe — when this should be answered]

  OPEN QUESTION 2: [same structure]

  RECOMMENDED NEXT ANALYSIS:
  Given these findings, the most valuable next analysis would be [describe].
  It would answer [question] and require [data source / effort level].
```

---

## Final Verification: The 5-Question Test

```
Before saving action_plan.md, run this test:

Read the Executive Summary and the Prioritised Actions table aloud.
Then answer each question from the audience's perspective:

  □ 1. What is happening?
       [can a non-technical person answer this from the Executive Summary? YES / NO]

  □ 2. Why is it happening?
       [can they answer this from the Key Findings Recap? YES / NO]

  □ 3. Why should I care?
       [can they answer this from the Business Impact section? YES / NO]

  □ 4. What opportunity am I missing?
       [can they answer this from the Strategic Opportunities section? YES / NO]

  □ 5. What should I do next?
       [can they answer this from the Prioritised Actions table? YES / NO]

If any answer is NO → go back and add what is missing before saving.
If all five are YES → save and present the pipeline complete summary.
```

---

## Output File: action_plan.md

```markdown
# Action Plan
Pipeline step: 6 of 6 — ambursaData ✅ COMPLETE
Date: [date]
Business question: [from data_brief.md]
Audience: [from data_brief.md]
Prepared by: ambursaData

---

## Executive Summary
[5 sentences. Full story. Forward-ready.]

---

## Key Findings Recap
• [Finding 1 — one sentence with key number]
• [Finding 2 — one sentence with key number]
• [Finding 3 — one sentence with key number]

---

## Business Impact Assessment

### Finding 1: [title]
**Current state:** [what the data shows]
**Trend:** [direction]
**Impact if unchanged:**
  → Revenue: [estimate or direction]
  → Cost: [estimate or direction]
  → Customers: [estimate or direction]
  → Risk: [description]
**Confidence:** HIGH / MEDIUM / LOW

[Repeat for each top finding]

---

## Strategic Opportunities

### Opportunity 1: [title]
**What the data shows:** [finding with number]
**What this means:** [plain English]
**What would need to be true:** [conditions]
**How to test it:** [smallest action]
**Potential impact:** [quantified or described]
**Decision needed:** [what leadership must decide]

[Repeat for each opportunity]

---

## Prioritised Actions

| Priority | Action | Reason | Owner | Deadline | Success Metric |
|----------|--------|--------|-------|----------|----------------|
| TIER 1   | [specific verb-first action] | [finding reference] | [owner] | [date] | [measurable outcome] |
| TIER 1   | | | | | |
| TIER 2   | | | | | |
| TIER 2   | | | | | |
| TIER 3   | Investigate: [question] | [why this matters] | [owner] | [date] | [what a confirmed answer looks like] |

---

## Success Metrics — 30 / 60 / 90 Day Checks

### Action: [name]
Metric: [what is measured]
Baseline: [current value]
30-day: [check]
60-day: [check]
90-day: [success threshold — YES or NO answerable]
Data source: [dashboard / table]
Review owner: [person]

[Repeat for each Tier 1 and Tier 2 action]

---

## Open Questions for Next Analysis

1. [Question] — matters because [decision] — data needed: [source] — by: [timeframe]
2. [Question] — matters because [decision] — data needed: [source] — by: [timeframe]

**Recommended next analysis:** [describe] — answers [question] — requires [data/effort]

---

## ✅ 5-Question Verification

1. What is happening?        → ANSWERED (Executive Summary, sentence 1)
2. Why is it happening?      → ANSWERED (Key Findings Recap)
3. Why should I care?        → ANSWERED (Business Impact Assessment)
4. What am I missing?        → ANSWERED (Strategic Opportunities)
5. What should I do next?    → ANSWERED (Prioritised Actions table)

---

## Pipeline Status — COMPLETE
Step 1 ✅ data-explorer  → data_brief.md
Step 2 ✅ sql-architect  → query_library.md
Step 3 ✅ insight-hunter → findings.md
Step 4 ✅ viz-builder    → dashboard_spec.md
Step 5 ✅ story-weaver   → data_story.md
Step 6 ✅ action-planner → action_plan.md
```

---

## Pipeline Complete Summary (MANDATORY)

After saving `action_plan.md` and verifying all 5 questions are answered, present this EXACTLY:

```
✅ ambursaData Pipeline Complete.

📊 PIPELINE SUMMARY:
  Step 1 ✅ data-explorer  → data_brief.md
  Step 2 ✅ sql-architect  → query_library.md
  Step 3 ✅ insight-hunter → findings.md
  Step 4 ✅ viz-builder    → dashboard_spec.md
  Step 5 ✅ story-weaver   → data_story.md
  Step 6 ✅ action-planner → action_plan.md

📋 DELIVERABLES READY:
  → Dashboard:   dashboard_spec.md (charts and HTML dashboard)
  → Story:       data_story.md     (plain-English narrative for stakeholders)
  → Action plan: action_plan.md    (prioritised actions with owners and metrics)

📌 TOP ACTION:
  [Tier 1 action #1 from the Prioritised Actions table]

🎯 5-QUESTION CHECK:
  1. What is happening?        ✅
  2. Why is it happening?      ✅
  3. Why should I care?        ✅
  4. What am I missing?        ✅
  5. What should I do next?    ✅

✅ This analysis is ready to present to stakeholders.
```

The pipeline is now complete.
No further steps required unless the audience requests revisions.
