---
name: data-explorer
description: >
  Step 1 of 6 in the ambursaData Pipeline. Profiles and explores any dataset
  — SQL table, CSV, Excel, or DataFrame — to understand its shape, quality,
  and patterns before any analysis begins. Produces a plain-English dataset
  brief that anyone can read, flags quality issues, and identifies the most
  promising dimensions and metrics for deeper work. Saves as data_brief.md.
---

# Data Explorer

You cannot tell a good story about data you do not understand.
Before you write a single query, before you build a single chart,
you need to know what you are working with.
What is in this data? What is missing? What looks suspicious?
Which columns actually matter?
Most bad analyses fail before they begin —
because the analyst assumed they understood the data
without ever checking.
Check first. Explore ruthlessly. Save as `data_brief.md`.

---

## The Mission

```
You are acting as a Senior Data Analyst on the first day with a new dataset.
Your job is to understand the data well enough to answer:
  1. What is this data describing?
  2. Is it trustworthy? What are its limits?
  3. What is the most interesting thing we could learn from it?
  4. What questions can it answer — and what can it NOT answer?

Output must be readable by a non-technical stakeholder.
Never use jargon without immediately explaining it.
```

---

## Step 1 — Understand the Business Context

```
BEFORE looking at the data, answer these questions:

  BUSINESS QUESTION (what are we trying to understand?):
    "We are trying to understand [business area] in order to [decision/outcome]."

  INTENDED AUDIENCE:
    Who will read the final analysis?
    → Board / executives: need high-level story, big numbers, clear actions
    → Operations team: need specifics, process detail, day-to-day metrics
    → Marketing: need customer behaviour, campaign performance, segments
    → Finance: need revenue, cost, margin, trend accuracy

  WHAT DECISIONS WILL THIS ANALYSIS INFORM?
    "The result of this analysis will help us decide [X]."
    If you cannot name a decision, ask: "What problem are we solving?"

  DATA SOURCE:
    Where does this data come from? (database / CSV / API / export)
    How often is it updated? (real-time / daily / weekly / static snapshot)
    Who created it? (internal team / external vendor / automated system)
    Is it raw data or already processed?
```

---

## Step 2 — Structural Profile

```
Run these checks on every dataset. Document every result.

FOR A SQL TABLE:
  -- Row count
  SELECT COUNT(*) AS total_rows FROM [table];

  -- Column names and types
  DESCRIBE [table]; -- or INFORMATION_SCHEMA.COLUMNS

  -- Date range (if time-based data)
  SELECT MIN(date_column), MAX(date_column) FROM [table];

  -- Distinct values per key column
  SELECT COUNT(DISTINCT [key_column]) FROM [table];

FOR A CSV / DATAFRAME (Python):
  import pandas as pd
  df = pd.read_csv('file.csv')

  print(df.shape)           # rows, columns
  print(df.dtypes)          # column types
  print(df.head(10))        # first 10 rows
  print(df.describe())      # statistics for numeric columns
  print(df.isnull().sum())  # missing values per column

DOCUMENT IN PLAIN ENGLISH:
  "This dataset contains [N] rows and [N] columns.
   It covers the period from [start] to [end].
   Each row represents [one transaction / one customer / one day / etc.].
   The main identifiers are [column names].
   The main metrics are [column names]."
```

---

## Step 3 — Data Quality Assessment

```
CHECK EVERY COLUMN FOR THESE ISSUES:

  MISSING VALUES:
    Which columns have nulls? What percentage?
    SQL: SELECT column, COUNT(*) - COUNT(column) AS nulls,
         ROUND(100.0 * (COUNT(*) - COUNT(column)) / COUNT(*), 1) AS pct_null
         FROM table GROUP BY 1;

    INTERPRETATION RULE:
    0–5% missing   → minor, usually safe to proceed
    5–20% missing  → note the limitation, may affect conclusions
    20%+ missing   → flag as a quality concern, do not rely on this column

  DUPLICATES:
    Are there rows that appear more than once?
    SQL: SELECT [key_columns], COUNT(*) AS n FROM table GROUP BY 1 HAVING n > 1;

    If duplicates exist: are they intentional (multiple events per ID)
    or a data error (same event recorded twice)?

  SUSPICIOUS VALUES:
    Look for values that are technically valid but practically impossible:
    → Negative quantities, ages over 120, dates in the future, prices of $0
    → Dates with wrong format (1900-01-01 often means "unknown")
    → Free-text fields with known bad values ("N/A", "null", "test", "UNKNOWN")
    → Outliers that are 10× the average (could be real or errors)

  CONSISTENCY:
    Does the same thing appear in multiple formats?
    → "United Kingdom", "UK", "U.K.", "UNITED KINGDOM" — same thing?
    → Date formats: 2024-01-15 vs 15/01/2024 vs January 15
    → Currency: mixed GBP and USD with no indicator?

QUALITY VERDICT:
  GREEN:  Data is clean and reliable. Proceed with confidence.
  AMBER:  Data has known issues. Document them. Conclusions should note limitations.
  RED:    Data has serious quality problems. Investigate before drawing conclusions.
```

---

## Step 4 — Column Intelligence

```
FOR EACH IMPORTANT COLUMN, IDENTIFY ITS ROLE:

  DIMENSIONS (what you slice the data by):
    Categories: region, product type, customer segment, channel, status
    Time: date, week, month, year
    Identifiers: customer ID, order ID, product ID

  METRICS (what you measure):
    Revenue, quantity, count, duration, score, rate, percentage
    These are the numbers that tell you HOW MUCH or HOW MANY.

  THE MOST INTERESTING COMBINATIONS:
    "If I look at [metric] by [dimension], what might I find?"
    Example: "If I look at revenue by region and month,
              I might find which regions are growing or declining."

COLUMN QUICK PROFILE:
  For each numeric column:
    MIN, MAX, AVG, MEDIAN
    Distribution: is it clustered or spread out?
    Does the average actually represent typical values, or are outliers pulling it?

  For each categorical column:
    How many distinct values?
    What is the top value and what % does it represent?
    Are there any unexpected categories?
```

---

## Step 5 — Pattern Spotting (Pre-Analysis)

```
BEFORE formal analysis, look for these at a glance:

  TIME PATTERNS:
    Is there a trend (going up, going down, flat)?
    Is there seasonality (same pattern repeats each week/month/year)?
    Are there spikes or drops at specific dates?

  DISTRIBUTION PATTERNS:
    Is the data evenly spread or concentrated in one area?
    Does 20% of something account for 80% of the total? (Pareto principle)
    Are there gaps (time periods or categories with zero data)?

  COMPARISON PATTERNS:
    Does one group perform significantly better or worse than others?
    Is there an obvious top performer and bottom performer?

  ANOMALIES:
    Is there anything that immediately stands out as unusual?
    One row with values 100× higher than the rest?
    A date column showing data from 1970 (usually means missing date was set to epoch)?

WRITE THIS IN PLAIN ENGLISH:
  "At first glance, the most interesting things about this data are:
   1. [observation in plain English]
   2. [observation in plain English]
   3. [observation in plain English]"
```

---

## Output File: data_brief.md

```markdown
# Data Brief
Pipeline step: 1 of 6 — ambursaData
Date: [date]
Dataset: [name or description]
Analyst: [your name]

---

## In Plain English
[2–3 sentences describing what this data is about, as you would explain it
to someone who has never seen it. No jargon.]

## Business Context
Question we are answering : [the business question]
Decision this will inform : [the decision]
Audience                  : [who will read the final analysis]

## Dataset Structure
Source          : [database / CSV / API / etc.]
Rows            : [N]
Columns         : [N]
Time period     : [start date – end date]
Each row is     : [one transaction / one customer / etc.]
Key identifiers : [column names]
Key metrics     : [column names]

## Data Quality Assessment
Overall quality : GREEN / AMBER / RED

| Column | Type | Missing % | Issues Found |
|--------|------|-----------|--------------|
[one row per important column]

Quality notes:
[List any limitations the analysis should acknowledge]

## Column Intelligence
Dimensions (how we slice) : [list]
Metrics (what we measure) : [list]
Most interesting combos   : [list 3 "metric by dimension" combinations]

## First Impressions (Pattern Spotting)
1. [Plain-English observation]
2. [Plain-English observation]
3. [Plain-English observation]

## What This Data Can Answer
Can answer     : [list 3–5 questions this data can reliably address]
Cannot answer  : [list 2–3 questions this data cannot address — missing dimensions, etc.]

## Recommended Next Step
[One sentence: what should the analyst focus on first, and why?]

---

## Pipeline Status
Step 1 ✅ data-explorer  → data_brief.md
Step 2 ⬜ sql-architect  → query_library.md
Step 3 ⬜ insight-hunter → findings.md
Step 4 ⬜ viz-builder    → dashboard_spec.md
Step 5 ⬜ story-weaver   → data_story.md
Step 6 ⬜ action-planner → action_plan.md
```

---

## Review Gate (MANDATORY)

After saving `data_brief.md`, present this EXACTLY:

```
✅ Data brief complete. Saved to data_brief.md.

📋 Summary:
- Dataset        : [name]
- Rows           : [N] | Columns: [N]
- Time period    : [range]
- Quality rating : GREEN / AMBER / RED
- Top quality issue : [if any]
- First impression  : [most interesting pattern spotted]
- Recommended focus : [what to analyse first]

Quality flags (must acknowledge in final story):
  [list any AMBER or RED issues]

👉 You can:
  - Approve → say "approved" or "write the SQL"
  - Add a data source → say "also explore [table/file]"
  - Change the business question → say "the question is actually [X]"

⏸️ Waiting for approval before SQL Architect runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `write the sql`, `sql architect`,
`proceed`, `next`, `go`, `data understood`, `start querying`
