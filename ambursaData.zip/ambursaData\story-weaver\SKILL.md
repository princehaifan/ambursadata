---
name: story-weaver
description: >
  Step 5 of 6 in the ambursaData Pipeline. Translates every technical finding
  into a plain-English narrative that any stakeholder can understand and act on.
  Uses the ambursaData 6-part storytelling framework: Big Picture → What the
  Data Reveals → Why It Matters → The Hidden Opportunity → What We Should Do →
  The Potential Impact. Written in British English. Zero jargon.
  Saves as data_story.md.
---

# Story Weaver

Data without a story is just numbers.
A story without data is just opinion.
Your job is to build the bridge.
Every finding you have uncovered — the trends, the comparisons, the anomalies,
the hidden opportunities — must now be translated into language
that an intelligent person who has never studied data analytics can understand.
Not dumbed down. Translated.
There is a difference.
You are not removing the insight. You are removing the barrier.
When you are done, a non-technical executive should be able to read this story,
understand exactly what is happening in their business,
and feel inspired and confident enough to act on it.
Save as `data_story.md`.

---

## The Standard That Must Be Met

```
BEFORE writing a single word, commit to this standard:

If a non-technical stakeholder reads this and cannot answer all five questions,
the story is not finished:

  1. What is happening?
  2. Why is it happening?
  3. Why should I care?
  4. What opportunity am I missing?
  5. What should I do next?

Every section of the story maps to one of these questions.
Write until all five are answered. Then stop.
```

---

## Prerequisites

```
READ FIRST: data_brief.md      → audience, business question, quality limitations
READ SECOND: findings.md       → top 3 findings, hidden opportunities, fact/interpretation split
READ THIRD: dashboard_spec.md  → charts and dashboards that will accompany the story
```

---

## The ambursaData 6-Part Story Framework

```
USE THIS STRUCTURE FOR EVERY ANALYSIS.
Adapt the length to the assignment.
A one-question analysis might need 1–2 paragraphs per section.
A full quarterly business review might need 3–5 paragraphs.
Scale to the complexity. Never pad. Never cut what matters.
```

---

## Part 1 — The Big Picture

```
PURPOSE: Answer "What is happening?" in plain English.
         The audience should understand the overall situation
         before they see a single number.

LENGTH: 1–2 short paragraphs. This is the opening scene.
        It sets the stage. It does not reveal the conclusion yet.

RULES:
  → Start with the business context, not the data.
  → Use everyday language and relatable references.
  → Do not lead with methodology, tools or query details.
  → Make the audience feel they already understand the landscape.

TEMPLATE:
  "[Organisation/team] has been [business activity] over [time period].
   This analysis looks at [what was measured], covering [scope],
   to answer the question: [business question in plain English].

   The data covers [date range], includes [N] records,
   and draws on [data sources]. [One sentence acknowledging
   any important quality limitations the audience should know.]"

EXAMPLE:
  "Over the past 12 months, our business has processed nearly 50,000 customer orders
   across five regions. This report looks at where our revenue is coming from,
   how customer behaviour has changed, and what that means for the year ahead.

   The analysis is based on transaction data from January to December 2024.
   All revenue figures are reported in British pounds and exclude VAT.
   One limitation worth noting: customer data for the Scotland region
   was incomplete for two months, so Scotland's figures should be treated
   as indicative rather than precise."
```

---

## Part 2 — What the Data Reveals

```
PURPOSE: Answer "What is happening?" with specific findings.
         Present the top 3 findings from findings.md.

LENGTH: One section per finding. Each section has:
  → A descriptive subheading that states the finding (not the topic)
  → 2–3 sentences explaining the finding in plain English
  → The key number, presented with context
  → A reference to the chart that supports it

RULES:
  → Lead with the insight, not the number.
  → Every number needs context. £4.2 million means nothing.
    £4.2 million — 23% above the same period last year — means something.
  → Explain what the chart shows. Do not say "as the chart shows" and leave it.
  → Never overwhelm with multiple statistics in one sentence.
  → If you must use a technical term, define it immediately.

THE NUMBER WITH CONTEXT RULE:
  BAD:  "Revenue was £4.2 million."
  GOOD: "Revenue reached £4.2 million — the highest quarterly figure in three years,
         and 23% above the same quarter last year."

  BAD:  "Customer retention rate was 72%."
  GOOD: "72% of customers who bought from us in the first half of the year came back
         and bought again. That means roughly 3 in every 10 customers did not return —
         a retention rate that is in line with industry average but below
         our own target of 80%."

TEMPLATE FOR EACH FINDING:
  ### [Finding Title — states the finding, not the topic]

  [Plain-English explanation: what happened, in 2 sentences]

  [The key number with context: "X — which means Y in real terms"]

  [Why this matters: what does this tell us about the business?]

  [Reference to the supporting chart: "The chart on the left shows how
   this has changed month by month."]
```

---

## Part 3 — Why It Matters

```
PURPOSE: Connect the findings to the audience's real concerns.
         This is where the story moves from "interesting" to "important."

LENGTH: 1–2 paragraphs.

THE BRIDGE EXERCISE:
  For each finding, ask: "So what?"
  Then ask "So what?" again.
  Keep asking until you reach a consequence the audience cares about.

  EXAMPLE:
    Finding: "Revenue per order has fallen 15% in the last 6 months."
    So what?  "We are selling the same number of orders but earning less per order."
    So what?  "If this continues, we will need 18% more orders to maintain revenue."
    So what?  "With our current marketing spend, we cannot generate 18% more orders
               without increasing costs significantly."
    Why it matters: "Unless we either increase the average order value or acquire
                     new customers, revenue will decline despite stable order volumes.
                     This is a critical strategic issue for the next quarter."

RULES:
  → Connect findings to revenue, cost, customers, or risk.
  → Quantify the real-world impact only when the data supports it.
     Never fabricate an impact estimate.
  → Be direct. Do not hide bad news in vague language.
  → Respect the audience's intelligence. Do not over-explain.

TEMPLATE:
  "These findings matter because [real-world consequence].
   [Specific calculation or implication, only if data-supported].
   For [the organisation/team/stakeholders], this means [practical implication].
   [One sentence on urgency or timing, if appropriate.]"
```

---

## Part 4 — The Hidden Opportunity

```
PURPOSE: Reveal the unexpected. The thing they were not looking for.
         This is the most valuable section. It is what separates
         a reporting analyst from a strategic data partner.

LENGTH: 1–3 paragraphs. As many opportunities as the data genuinely supports.
        Never fabricate or speculate beyond what the data shows.

RULES:
  → Base every opportunity on a specific observation from findings.md.
  → Distinguish clearly between evidence-based findings and hypotheses.
  → Label hypotheses as hypotheses. "This suggests..." not "This proves..."
  → The opportunity should feel surprising but logical in hindsight.

THE TRANSFORMATIONAL QUESTION PROMPTS:
  "What is the organisation overlooking?"
  "Which small change could generate a disproportionate improvement?"
  "What does the top-performing segment do that the bottom does not?"
  "What customer behaviour pattern could inspire a new product?"
  "What would happen if we scaled what is already working?"

TEMPLATE:
  "Beyond the headline findings, the data reveals an unexpected opportunity.

   [Plain-English description of the pattern or anomaly.]

   [Why this is surprising or overlooked.]

   [What it could mean for the business — presented as a hypothesis,
    not a conclusion, unless the data confirms it.]

   [What would need to be true for this opportunity to be real,
    and how it could be tested or validated.]"

LABEL CLEARLY:
  CONFIRMED: "The data shows that X is happening."
  HYPOTHESIS: "This suggests that Y might be true — this warrants investigation."
  OPPORTUNITY: "If Y is confirmed, the potential impact is [describe without fabrication]."
```

---

## Part 5 — What We Should Do

```
PURPOSE: Answer "What should I do next?" with clear, prioritised actions.
         (Full detail goes in action_plan.md. This section is the brief version.)

LENGTH: A short numbered list. 3–5 actions maximum in this section.
         Long-form reasoning goes in Step 6.

RULES:
  → Be specific. "Investigate X" is not an action. "Review pricing for Product Y
    with the Sales team by [date]" is an action.
  → Prioritise by impact and feasibility.
  → Acknowledge what you do not know, and name it as a required investigation.
  → Each action should be achievable by someone in the room.

TEMPLATE:
  "Based on these findings, we recommend three immediate actions:

   1. [Specific action] — [reason in one clause] — [owner, if known] — [timeframe]
   2. [Specific action] — [reason in one clause] — [owner, if known] — [timeframe]
   3. [Specific action] — [reason in one clause] — [owner, if known] — [timeframe]

   Additionally, the following questions should be investigated before the next review:
   → [Open question]
   → [Open question]"
```

---

## Part 6 — The Potential Impact

```
PURPOSE: Show what could improve if the recommendations are acted upon.
         Quantify only where the data provides a basis.
         Where it does not, describe the direction of impact.

RULES:
  → Never invent a revenue or cost projection without a data basis.
  → If you calculate an impact, show the logic.
  → "Fixing this could save approximately [X]" is acceptable only if
    the calculation is transparent and reasonable.
  → If you cannot quantify, describe: "Earlier intervention in this segment
    is likely to improve retention — the precise impact depends on
    how quickly new processes can be implemented."

TEMPLATE:
  "If these actions are taken, the most likely outcomes are:

   → [Outcome 1]: [describe the improvement and, if calculable, the scale]
   → [Outcome 2]: [describe the improvement]
   → [Outcome 3]: [describe the improvement]

   The most significant risk of inaction is [specific consequence]."
```

---

## The Plain-English Toolkit

```
USE THESE TRANSLATIONS:

TECHNICAL TERM           → PLAIN ENGLISH
Cohort analysis          → Looking at a group of customers who all started at the same time
Year-over-year           → Compared to the same time last year
Moving average           → A smoothed average that removes day-to-day noise
Correlation              → Two things tend to move in the same direction
Null values              → Missing data
Outlier                  → A result that is unusually high or low compared to everything else
Seasonality              → Patterns that repeat at the same time every year
Statistical significance → The difference is large enough that it is unlikely to be luck
Churn                    → Customers who stop buying from us
Retention rate           → The percentage of customers who come back and buy again
ARPU (Avg Revenue/User)  → How much each customer spends on average
Conversion rate          → The percentage of people who do the thing we want them to do
```

---

## Output File: data_story.md

```markdown
# Data Story
Pipeline step: 5 of 6 — ambursaData
Date: [date]
Business question: [from data_brief.md]
Audience: [from data_brief.md]
Prepared by: ambursaData

---

## Executive Summary
[3–5 sentences. The entire story in one paragraph.
 Lead with the most important finding. End with the most important action.
 A busy executive who reads only this paragraph must still understand what matters.]

---

## Part 1 — The Big Picture
[1–2 paragraphs. Context, scope, limitations.]

---

## Part 2 — What the Data Reveals

### [Finding 1 Title — states the finding]
[Plain English. Key number with context. Chart reference.]

### [Finding 2 Title — states the finding]
[Plain English. Key number with context. Chart reference.]

### [Finding 3 Title — states the finding]
[Plain English. Key number with context. Chart reference.]

---

## Part 3 — Why It Matters
[1–2 paragraphs. Real-world consequences. No jargon.]

---

## Part 4 — The Hidden Opportunity
[1–3 paragraphs. Unexpected finding. Clearly labelled as confirmed / hypothesis.]

---

## Part 5 — What We Should Do
1. [Specific action — reason — owner — timeframe]
2. [Specific action — reason — owner — timeframe]
3. [Specific action — reason — owner — timeframe]

Open questions for investigation:
→ [question]
→ [question]

---

## Part 6 — The Potential Impact
[Outcomes. Quantified only where the data supports it. Direction if not.]

---

## Quality Note
[Any data limitations from data_brief.md that the audience should keep in mind]

---

## Pipeline Status
Step 1 ✅ data-explorer  → data_brief.md
Step 2 ✅ sql-architect  → query_library.md
Step 3 ✅ insight-hunter → findings.md
Step 4 ✅ viz-builder    → dashboard_spec.md
Step 5 ✅ story-weaver   → data_story.md
Step 6 ⬜ action-planner → action_plan.md
```

---

## Review Gate (MANDATORY)

After saving `data_story.md`, present this EXACTLY:

```
✅ Data story complete. Saved to data_story.md.

📋 Story Quality Check:
- Can a non-technical person answer all 5 questions? YES / NO
  1. What is happening?        [one sentence from the story]
  2. Why is it happening?      [one sentence from the story]
  3. Why should I care?        [one sentence from the story]
  4. What am I missing?        [one sentence from the story]
  5. What should I do next?    [one sentence from the story]

- Jargon-free?    YES / NO [flag any remaining jargon]
- Quality caveats included? YES / NO

👉 You can:
  - Approve → say "approved" or "build the action plan"
  - Rewrite a section → say "rewrite part [N]: [direction]"
  - Add more plain-English → say "simplify [section]"
  - Sharpen the hidden opportunity → say "expand the opportunity section"

⏸️ Waiting for approval before Action Planner runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the action plan`, `action planner`,
`proceed`, `next`, `go`, `story approved`, `plan the actions`
