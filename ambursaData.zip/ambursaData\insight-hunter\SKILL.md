---
name: insight-hunter
description: >
  Step 3 of 6 in the ambursaData Pipeline. Runs exploratory data analysis
  on query results: finds patterns, trends, anomalies, correlations and
  hidden opportunities. Applies statistical sense-checks. Separates facts
  from interpretations. Identifies the 3–5 findings that matter most.
  Writes every finding in plain English before any chart is drawn.
  Saves as findings.md.
---

# Insight Hunter

A finding is not a number. A finding is a number that means something.
"Revenue was £4.2 million last quarter" is a number.
"Revenue was £4.2 million last quarter — 23% below the same quarter last year,
driven entirely by a collapse in the North West region after a key account left"
is a finding.
Your job is to turn query results into findings.
Every finding must answer: what happened, why it matters, and what is unusual.
If a non-technical person reads your finding and cannot understand why they should care,
it is not a finding yet. Keep digging.
Save as `findings.md`.

---

## Prerequisites

```
READ FIRST: data_brief.md    → business question, audience, quality limitations
READ SECOND: query_library.md → query results, plain-English explanations
```

---

## Step 1 — Read the Results Before Drawing Conclusions

```
THE ANALYST'S DISCIPLINE:
  Look at the actual data before you decide what it shows.
  Most analysts form a conclusion first and then find the numbers that support it.
  This produces misleading analyses. Do not do this.

FOR EACH QUERY RESULT, DO THIS FIRST:
  1. Read every row in the sample output.
  2. Find the highest value. Find the lowest. Find the median.
  3. Ask: does anything immediately seem wrong?
  4. Ask: does the top-line total match expectations?
  5. Ask: what is the most surprising thing in this result?

THE SANITY CHECK:
  Take the total or the headline number.
  Can you verify it a different way?
  Example: "Total revenue is £4.2M. Last year it was £5.5M.
            That implies a 24% decline. Does that match what
            the business believes is happening?"
  If the sanity check fails → investigate before proceeding.
  Errors in analysis cause worse decisions than no analysis at all.
```

---

## Step 2 — The Five Analytical Lenses

```
APPLY ALL FIVE LENSES TO YOUR DATA.
Not every lens will produce a finding. But every finding comes from one of these.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LENS 1: TREND (what is changing over time?)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Questions to ask:
    Is the metric going up, down, or flat?
    Is the rate of change accelerating or decelerating?
    When did it change? What was different about that period?
    Is the trend consistent across all segments, or is one segment driving it?

  What to calculate:
    Month-over-month change (absolute and percentage)
    Year-over-year comparison (removes seasonality)
    Rolling 3-month average (removes noise, shows the real trend)

  Plain-English finding format:
    "[Metric] has [increased/decreased] by [X%] over [period].
     The change began in [month] and has [accelerated/held steady/slowed]
     since then. The [segment] is the primary driver of this change."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LENS 2: COMPARISON (how do different groups differ?)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Questions to ask:
    Which segment, region, or product performs best? By how much?
    Which performs worst? Is the gap growing or shrinking?
    Is the top performer an outlier, or is performance clustered?
    Does the same pattern hold across all time periods?

  What to calculate:
    Rank by metric. Gap between top and median. Gap between top and bottom.
    Index: how does each segment compare to the average? (avg = 100)
    Concentration: does the Pareto rule apply? (top 20% = 80% of total?)

  Plain-English finding format:
    "[Segment A] generates [X times] more [metric] than the average,
     while [Segment B] is [Y%] below the average.
     The top [N]% of [customers/products/regions] account for [X%] of total [metric]."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LENS 3: DISTRIBUTION (how is the metric spread?)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Questions to ask:
    Is the distribution normal (bell curve) or skewed?
    Are there clusters? (e.g., two groups of customers with very different spend)
    Are there outliers? Are they errors or genuinely exceptional cases?
    Does the average actually represent typical behaviour?

  When average misleads:
    If the top 1% of customers spend 100× the average,
    the average is not a useful description of typical customer behaviour.
    Use the median (middle value) instead, and report both.

  Plain-English finding format:
    "The average [metric] is [X], but the median is [Y].
     This gap is caused by a small number of [high-value customers / large orders]
     that pull the average up. Most [customers / orders] are closer to [Y]."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LENS 4: CORRELATION (do two things move together?)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Questions to ask:
    When [X] goes up, does [Y] tend to go up too?
    Is there a lag? (do changes in X predict changes in Y one month later?)
    Does the correlation hold in all segments or just some?

  IMPORTANT RULE: Correlation is not causation.
    "Sales go up when it rains" might be true in an umbrella shop.
    It does not mean rain causes sales growth. Document both the correlation
    and the most plausible explanation, separately.

  Plain-English finding format:
    "There is a [strong/moderate/weak] relationship between [X] and [Y].
     When [X] increases by [amount], [Y] tends to increase by [amount].
     A likely explanation is [reason], though further investigation is needed
     to confirm causation."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LENS 5: ANOMALY (what does not fit the pattern?)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Questions to ask:
    Is there one month / one region / one product that breaks the pattern?
    Is there a gap in the data that should not be there?
    Is there a category that should exist but does not appear in the results?

  Anomaly types:
    POSITIVE: unexpectedly high performance — worth understanding and replicating
    NEGATIVE: unexpectedly low performance — worth investigating and fixing
    MISSING: an expected record that is absent — may be a data quality issue

  Plain-English finding format:
    "[Month/Region/Product] is an outlier: [metric] was [X],
     compared to an average of [Y] across all other periods.
     This is [X times/X%] [above/below] what would be expected.
     Possible explanations: [list 2–3 hypotheses]."
```

---

## Step 3 — Rank the Findings by Impact

```
NOT ALL FINDINGS ARE EQUAL.
Prioritise findings that:
  → Are surprising (the audience does not already know this)
  → Are actionable (someone can do something with this)
  → Are large in scale (affect significant revenue, cost, or customers)
  → Change a decision the audience was about to make

FINDING RANK TEMPLATE:
  | # | Finding | Surprising? | Actionable? | Scale | Priority |
  |---|---------|-------------|-------------|-------|----------|
  | 1 |         |             |             |       |          |
  | 2 |         |             |             |       |          |

THE TOP 3 FINDINGS are the ones that drive the story in Step 5.
The rest are supporting evidence or appendix material.

DISTINGUISH CLEARLY:
  FACTS:          things the data directly shows (numbers, counts, percentages)
  INTERPRETATIONS: what you believe the facts mean
  HYPOTHESES:     what might explain the facts — requires further investigation
  RECOMMENDATIONS: what someone should do — that is Step 6, not this step
```

---

## Step 4 — The Hidden Opportunity Scan

```
THIS IS THE MOST VALUABLE PART OF THE ANALYSIS.
Most analysts stop at "what happened."
ambursaData goes further: "what does this reveal that we were not looking for?"

THE TRANSFORMATIONAL QUESTIONS:
  □ What is the organisation overlooking?
  □ Which small change could generate a disproportionate improvement?
  □ Where is money, time or effort being wasted without anyone noticing?
  □ What customer behaviour pattern could inspire a new product or service?
  □ What is the top 10% doing that the bottom 50% is not?
  □ If we fixed just one thing, what would have the biggest impact?
  □ What would this data look like in 12 months if current trends continue?
     Is that acceptable?

FORMAT:
  HIDDEN OPPORTUNITY: [title]
  What the data shows: [specific finding that led to this]
  What it suggests: [the opportunity or risk]
  Who this affects: [department / customer segment / product]
  Estimated impact: [quantify only if the data supports it — never fabricate]
  What would need to happen: [the conditions for this opportunity to be captured]
```

---

## Output File: findings.md

```markdown
# Findings
Pipeline step: 3 of 6 — ambursaData
Date: [date]
Business question: [from data_brief.md]

---

## Top 3 Findings

### Finding 1: [title]
**In plain English:** [2–3 sentences a non-analyst can understand]
**The numbers:** [specific figures]
**Why it matters:** [the business implication]
**Confidence:** HIGH / MEDIUM / LOW
**Limitation:** [any data quality caveat]

### Finding 2: [title]
[same structure]

### Finding 3: [title]
[same structure]

---

## Supporting Findings
[Additional findings that add context but are not the headline story]

---

## Anomalies
[Any data points that break the pattern — with possible explanations]

---

## Hidden Opportunities
| Opportunity | Evidence | Who it affects | Est. impact |
|-------------|----------|----------------|-------------|
[1–3 rows]

---

## Facts vs. Interpretations vs. Hypotheses
CONFIRMED FACTS (data shows directly):
  •
INTERPRETATIONS (what we believe this means):
  •
HYPOTHESES (possible explanations — not yet confirmed):
  •
QUESTIONS RAISED (things we should investigate further):
  •

---

## Pipeline Status
Step 1 ✅ data-explorer  → data_brief.md
Step 2 ✅ sql-architect  → query_library.md
Step 3 ✅ insight-hunter → findings.md
Step 4 ⬜ viz-builder    → dashboard_spec.md
Step 5 ⬜ story-weaver   → data_story.md
Step 6 ⬜ action-planner → action_plan.md
```

---

## Review Gate (MANDATORY)

After saving `findings.md`, present this EXACTLY:

```
✅ Findings complete. Saved to findings.md.

📋 Summary:
- Top finding    : [one sentence]
- Finding 2      : [one sentence]
- Finding 3      : [one sentence]
- Anomalies      : [N found]
- Hidden opps    : [N identified]
- Confidence     : [HIGH/MEDIUM/LOW — and why if not HIGH]

Quality flags (from data_brief.md that affect confidence):
  [list]

👉 You can:
  - Approve → say "approved" or "build the visuals"
  - Add a finding → say "also investigate: [question]"
  - Challenge a finding → say "finding [N] seems wrong because [reason]"

⏸️ Waiting for approval before Viz Builder runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the visuals`, `viz builder`,
`proceed`, `next`, `go`, `findings confirmed`, `visualise`
