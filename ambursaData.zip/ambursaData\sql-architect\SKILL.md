---
name: sql-architect
description: >
  Step 2 of 6 in the ambursaData Pipeline. Writes clean, optimised SQL
  for any warehouse dialect (Snowflake, BigQuery, Databricks, PostgreSQL,
  MySQL, SQLite). Handles joins, CTEs, window functions, aggregations,
  and performance tuning. Explains every query in plain English so
  non-technical stakeholders understand what was asked of the data.
  Saves as query_library.md.
---

# SQL Architect

SQL is the language you use to ask questions of data.
Most people write SQL that answers the question they asked.
Great SQL analysts write SQL that also asks: is this answer correct?
The query is not done when it runs. It is done when you are confident
the result is right.
This skill writes the queries, optimises them, and explains every one
in plain English — so anyone reading the final story knows
what was actually measured, not just what the numbers say.
Save as `query_library.md`.

---

## Prerequisites

```
READ FIRST: data_brief.md → table names, column names, data types,
                             quality issues to account for,
                             business question to answer
```

---

## Step 1 — Query Strategy (Plan Before You Write)

```
BEFORE writing SQL, answer:

  1. What question does this query answer?
     State it in plain English first.
     Example: "How much revenue did each region generate per month,
                and is any region trending significantly up or down?"

  2. Which tables do I need?
     List them and explain the join logic.
     Example: "orders joined to customers on customer_id,
                then to products on product_id."

  3. What filters apply?
     Date range? Specific status? Exclude test accounts?

  4. What is the grain of the result?
     "Each row in the result represents [one month / one customer / one product]."
     If you do not know the grain, you have not designed the query yet.

  5. What could go wrong?
     Duplicates from a many-to-many join?
     Nulls in a column you are summing?
     Inconsistent date formats?
     Filtered-out rows that should be included?

WRITE THE PLAIN ENGLISH QUESTION FIRST.
Then write the SQL. Never the other way around.
```

---

## Step 2 — The Query Toolkit

```
THESE ARE THE BUILDING BLOCKS. USE THE RIGHT ONE FOR EACH QUESTION.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AGGREGATIONS (measuring totals and averages)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  -- Total revenue by region and month
  SELECT
    region,
    DATE_TRUNC('month', order_date) AS month,
    SUM(revenue)                    AS total_revenue,
    COUNT(DISTINCT order_id)        AS order_count,
    ROUND(AVG(revenue), 2)          AS avg_order_value
  FROM orders
  WHERE order_date >= '2024-01-01'
  GROUP BY 1, 2
  ORDER BY 1, 2;

  PLAIN ENGLISH: "For each region and each month, sum the revenue,
                  count the number of orders, and calculate the average order value."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CTEs (Common Table Expressions — breaking complex queries into readable steps)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  -- Revenue by region, with month-over-month change
  WITH monthly_revenue AS (
    SELECT
      region,
      DATE_TRUNC('month', order_date) AS month,
      SUM(revenue)                    AS revenue
    FROM orders
    GROUP BY 1, 2
  ),
  with_lag AS (
    SELECT
      region,
      month,
      revenue,
      LAG(revenue) OVER (PARTITION BY region ORDER BY month) AS prev_month_revenue
    FROM monthly_revenue
  )
  SELECT
    region,
    month,
    revenue,
    prev_month_revenue,
    ROUND(100.0 * (revenue - prev_month_revenue) / NULLIF(prev_month_revenue, 0), 1) AS pct_change
  FROM with_lag
  ORDER BY region, month;

  PLAIN ENGLISH: "Step 1: total revenue by region and month.
                  Step 2: for each region, look up last month's revenue.
                  Step 3: calculate the percentage change between this month and last."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WINDOW FUNCTIONS (ranking, running totals, comparisons)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  -- Rank customers by revenue within each region
  SELECT
    customer_id,
    region,
    total_spend,
    RANK() OVER (PARTITION BY region ORDER BY total_spend DESC) AS rank_in_region,
    ROUND(100.0 * total_spend / SUM(total_spend) OVER (PARTITION BY region), 1) AS pct_of_region_revenue
  FROM customer_spend;

  PLAIN ENGLISH: "For each customer, calculate their rank in their region
                  by total spend, and what percentage of their region's
                  total revenue they represent."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
JOINS (combining tables)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  -- Customer orders with product detail
  SELECT
    o.order_id,
    o.order_date,
    c.customer_name,
    c.segment,
    p.product_name,
    p.category,
    o.quantity,
    o.revenue
  FROM orders o
  INNER JOIN customers c ON o.customer_id = c.customer_id
  INNER JOIN products  p ON o.product_id  = p.product_id
  WHERE o.status = 'completed'
    AND o.order_date >= CURRENT_DATE - INTERVAL '90 days';

  JOIN TYPES:
    INNER JOIN : only rows that match in BOTH tables
    LEFT JOIN  : all rows from left table, matched or not (nulls where no match)
    RIGHT JOIN : all rows from right table (rarely needed — use LEFT JOIN instead)
    FULL OUTER : all rows from both tables (use to find unmatched records)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATA QUALITY QUERIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  -- Missing values by column
  SELECT
    COUNT(*)                                      AS total_rows,
    COUNT(*) - COUNT(customer_id)                 AS missing_customer_id,
    COUNT(*) - COUNT(revenue)                     AS missing_revenue,
    COUNT(*) - COUNT(order_date)                  AS missing_date
  FROM orders;

  -- Duplicates check
  SELECT order_id, COUNT(*) AS n
  FROM orders
  GROUP BY order_id
  HAVING n > 1;

  -- Outliers (revenue more than 3 standard deviations from mean)
  WITH stats AS (
    SELECT AVG(revenue) AS mean, STDDEV(revenue) AS sd FROM orders
  )
  SELECT o.*, s.mean, s.sd
  FROM orders o, stats s
  WHERE ABS(o.revenue - s.mean) > 3 * s.sd;
```

---

## Step 3 — Dialect Translations

```
THE SAME QUERY IN DIFFERENT WAREHOUSES:

  DATE TRUNCATION:
    PostgreSQL  : DATE_TRUNC('month', date_col)
    BigQuery    : DATE_TRUNC(date_col, MONTH)
    Snowflake   : DATE_TRUNC('month', date_col)
    SQL Server  : DATEADD(month, DATEDIFF(month, 0, date_col), 0)
    MySQL       : DATE_FORMAT(date_col, '%Y-%m-01')
    SQLite      : strftime('%Y-%m-01', date_col)

  DATE DIFFERENCE:
    PostgreSQL  : EXTRACT(day FROM end_date - start_date)
    BigQuery    : DATE_DIFF(end_date, start_date, DAY)
    Snowflake   : DATEDIFF('day', start_date, end_date)
    SQL Server  : DATEDIFF(day, start_date, end_date)
    MySQL       : DATEDIFF(end_date, start_date)

  STRING CONCATENATION:
    Most        : CONCAT(col1, ' ', col2)
    PostgreSQL  : col1 || ' ' || col2

  NULL HANDLING:
    COALESCE(value, 0)     -- replaces NULL with 0
    NULLIF(value, 0)       -- replaces 0 with NULL (prevents divide-by-zero)
    IFNULL (MySQL/SQLite)  -- same as COALESCE for two arguments

  SAFE DIVIDE (avoid division by zero):
    ROUND(100.0 * numerator / NULLIF(denominator, 0), 1)
```

---

## Step 4 — Query Quality Standards

```
EVERY QUERY MUST PASS THESE CHECKS BEFORE BEING SHARED:

  □ DOES IT ANSWER THE STATED PLAIN-ENGLISH QUESTION?
    Re-read the question. Does the SELECT clause return exactly what was asked?

  □ IS THE GRAIN CORRECT?
    What does one row in the result represent?
    Is that the right level of detail for the question?

  □ ARE NULLS HANDLED?
    If you are summing a column with nulls, SUM ignores nulls by default.
    But COUNT(*) counts null rows. Document this.
    Use COALESCE where needed.

  □ COULD JOINS CREATE DUPLICATE ROWS?
    If joining on a non-unique key, one-to-many joins multiply rows.
    Validate: compare row count before and after the join.
    SQL: SELECT COUNT(*) before vs. after joining.

  □ ARE FILTERS CORRECT?
    Does the WHERE clause include/exclude exactly the right records?
    Test: add SELECT * without aggregation and visually check 5–10 rows.

  □ ARE THE RESULTS REASONABLE?
    Does the top-line number pass a sanity check?
    If total revenue is $5 billion and the company turns over £10 million,
    something is wrong.

  □ IS THE CODE READABLE?
    One SELECT clause item per line.
    Meaningful aliases (rev not r).
    Comments on complex logic.
    CTEs named after what they contain, not step1/step2.
```

---

## Step 5 — Plain-English Query Explanations

```
FOR EVERY QUERY, WRITE A PLAIN-ENGLISH EXPLANATION.
This is non-negotiable. It goes in the final story.

FORMAT:
  QUERY NAME: [descriptive name]
  QUESTION ANSWERED: [plain-English question]
  WHAT IT DOES:
    "This query [verb] [what] from [which tables],
     [filters] to [specific conditions],
     and [groups/orders/calculates] by [dimensions].
     The result shows [one row per X], with columns for [Y, Z]."
  ASSUMPTIONS MADE:
    [any filters or exclusions that affect the result]
  LIMITATIONS:
    [what this query cannot tell us]

EXAMPLE:
  QUERY NAME: monthly_revenue_by_region
  QUESTION ANSWERED: How much revenue did each region generate each month?
  WHAT IT DOES:
    "This query adds up all completed order revenue from the orders table,
     grouped by region and calendar month.
     Orders with a status of 'cancelled' or 'refunded' are excluded.
     The result shows one row per region-month combination,
     with columns for total revenue, number of orders,
     and average order value."
  ASSUMPTIONS MADE:
    "Only completed orders are included. Refunded orders are excluded."
  LIMITATIONS:
    "Does not account for partial refunds. Revenue is recorded
     on the order date, not the payment date."
```

---

## Output File: query_library.md

```markdown
# Query Library
Pipeline step: 2 of 6 — ambursaData
Date: [date]
Dataset: [from data_brief.md]
Dialect: [Snowflake / BigQuery / PostgreSQL / etc.]

---

## Query Index
| # | Query Name | Business Question Answered |
|---|------------|---------------------------|
| 1 |            |                           |
| 2 |            |                           |
| 3 |            |                           |

---

## Query 1: [name]

**Business Question:** [plain English]

**Plain-English Explanation:**
[What it does, what tables, what filters, what grain, what columns]

**Assumptions:** [any exclusions or filters]
**Limitations:** [what this cannot tell us]

**SQL:**
```sql
[clean, commented SQL]
```

**Sample Result (first 5 rows):**
[paste sample output or describe expected structure]

---

[Repeat for each query]

---

## Combined Dataset (if multiple queries joined)
[describe the final combined dataset if queries feed into each other]

## Data Quality Notes Applied
[list any quality issues from data_brief.md that were handled in SQL,
 and how — e.g. "COALESCE used on revenue column to treat nulls as 0"]

---

## Pipeline Status
Step 1 ✅ data-explorer  → data_brief.md
Step 2 ✅ sql-architect  → query_library.md
Step 3 ⬜ insight-hunter → findings.md
Step 4 ⬜ viz-builder    → dashboard_spec.md
Step 5 ⬜ story-weaver   → data_story.md
Step 6 ⬜ action-planner → action_plan.md
```

---

## Review Gate (MANDATORY)

After saving `query_library.md`, present this EXACTLY:

```
✅ Query library complete. Saved to query_library.md.

📋 Summary:
- Dialect        : [warehouse]
- Queries written: [N]
- Questions answered:
    1. [plain English]
    2. [plain English]
    3. [plain English]
- Quality issues handled: [list from data_brief.md]
- Any query limitations to note in the story: [list]

👉 You can:
  - Approve → say "approved" or "find the insights"
  - Add a query → say "also query: [plain-English question]"
  - Fix a query → say "fix query [N]: [what is wrong]"
  - Translate dialect → say "translate to [dialect]"

⏸️ Waiting for approval before Insight Hunter runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `find the insights`, `insight hunter`,
`proceed`, `next`, `go`, `queries done`, `analyse the results`
