---
name: viz-builder
description: >
  Step 4 of 6 in the ambursaData Pipeline. Selects the right chart type
  for each finding, builds publication-quality visualisations in Python
  (Matplotlib, Seaborn, Plotly) and self-contained HTML dashboards with
  filters and KPI cards. Every chart has a title that states the finding,
  not just the topic. Saves as dashboard_spec.md.
---

# Viz Builder

A chart is not an illustration. A chart is an argument.
Every chart should answer one specific question.
Every chart title should state the answer, not the question.
"Revenue by Region" is a topic. It tells you nothing.
"The North drives 60% of revenue, but it is the only region declining" is an argument.
Build charts that make arguments. Build dashboards that tell stories.
Make every visualisation something a non-technical person can understand
in under 10 seconds.
Save as `dashboard_spec.md`.

---

## Prerequisites

```
READ FIRST: findings.md     → the top 3 findings and hidden opportunities
READ SECOND: data_brief.md  → the audience (executive / operational / mixed)
```

---

## Step 1 — Match the Chart to the Question

```
THE CHART TYPE SELECTION GUIDE:

SHOWING CHANGE OVER TIME → LINE CHART
  When to use: trend data with 5+ time points
  When NOT to use: fewer than 4 points (use a bar), non-continuous time
  Title format: "[Metric] has [risen/fallen] [X%] since [date]"
  Example: "Monthly revenue has fallen 18% since January 2024"

COMPARING CATEGORIES → BAR CHART (horizontal or vertical)
  When to use: comparing a metric across a small number of categories (2–10)
  Horizontal bars: when category names are long, or there are 6+ categories
  Vertical bars: when time is on the x-axis (column chart)
  Title format: "[Segment A] outperforms [Segment B] by [X]"
  Example: "The South region generates 3× more revenue per customer than the North"

SHOWING PROPORTIONS → PIE / DONUT CHART (use sparingly)
  When to use: showing parts of a whole, only 3–5 categories, one clear dominant segment
  When NOT to use: more than 5 categories, when precise comparison matters
  Alternative: 100% stacked bar (better for comparison across time)
  Title format: "[Category] accounts for [X%] of total [metric]"

SHOWING RELATIONSHIP BETWEEN TWO VARIABLES → SCATTER PLOT
  When to use: testing whether two metrics correlate
  Label the axes clearly. Add a trend line.
  Title format: "[Variable A] increases with [Variable B]"
  Example: "Higher customer tenure is associated with higher lifetime value"

SHOWING DISTRIBUTION → HISTOGRAM or BOX PLOT
  When to use: understanding how a metric is spread across records
  Box plot: comparing distribution across categories
  Title format: "Most [items] fall between [X] and [Y] — but outliers reach [Z]"

KPI CARDS (for executive dashboards)
  When to use: showing a single headline metric with context
  Always include: the number, the comparison (vs. last period), the direction arrow
  Format: Big number + "vs [period]" + % change + colour (green/red)

COMBINED (multi-chart) DASHBOARD
  When to use: executive overview, team monitoring, stakeholder report
  Layout: KPI cards at the top, trend charts in the middle, comparison details below
  Principle: most important insight should be visible without scrolling
```

---

## Step 2 — The Chart Quality Checklist

```
EVERY CHART MUST PASS THESE CHECKS:

  □ THE TITLE STATES THE FINDING (not just the topic)
    BAD:  "Sales by Month"
    GOOD: "Sales declined every month from March to August 2024"

  □ THE AXES ARE LABELLED WITH UNITS
    "Revenue (£000s)" not "Revenue"
    "Month (Jan–Dec 2024)" not "Month"
    Y-axis starts at zero for bar charts (truncation misleads)

  □ COLOUR IS USED PURPOSEFULLY
    One colour for neutral data. Accent colour for the highlighted finding.
    Red/orange for negative. Green for positive.
    Never use more than 4–5 colours in one chart.
    Test for colour-blind accessibility: use patterns or labels as backup.

  □ THE DATA IS DIRECTLY LABELLED (where space allows)
    Numbers on bars remove the need for a legend.
    Percentages on pie/donut charts.
    Data labels on the most important lines.

  □ GRID LINES ARE MINIMAL
    Light horizontal grid lines only. No vertical grid lines. No box borders.
    "Chart junk" (unnecessary decoration) reduces clarity.

  □ THE SOURCE IS NOTED
    "Source: [table name], [date range]" in small text below the chart.

  □ NON-TECHNICAL PERSON TEST
    Show the chart to someone who has not seen the data.
    Can they understand the finding in 10 seconds?
    If not: simplify the chart or rewrite the title.
```

---

## Step 3 — Python Chart Code Templates

```python
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TEMPLATE 1: LINE CHART — Trend Over Time
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

# df must have: 'month' (datetime) and 'revenue' (numeric)
fig, ax = plt.subplots(figsize=(10, 5))

ax.plot(df['month'], df['revenue'], color='#2563EB', linewidth=2.5, marker='o', markersize=4)
ax.fill_between(df['month'], df['revenue'], alpha=0.08, color='#2563EB')

# Annotate the last point
last = df.iloc[-1]
ax.annotate(f"£{last['revenue']:,.0f}", xy=(last['month'], last['revenue']),
            xytext=(5, 8), textcoords='offset points', fontsize=9)

ax.set_title("Monthly revenue has fallen 18% since January 2024",
             fontsize=13, fontweight='bold', pad=12)
ax.set_xlabel("Month", fontsize=10)
ax.set_ylabel("Revenue (£)", fontsize=10)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'£{x:,.0f}'))
ax.grid(axis='y', alpha=0.3, linestyle='--')
ax.spines[['top', 'right']].set_visible(False)

plt.figtext(0.12, 0.01, "Source: orders table, Jan–Aug 2024", fontsize=8, color='grey')
plt.tight_layout()
plt.savefig("monthly_revenue_trend.png", dpi=150, bbox_inches='tight')
plt.show()

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TEMPLATE 2: HORIZONTAL BAR CHART — Category Comparison
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
import pandas as pd
import matplotlib.pyplot as plt

# df must have: 'region' (str) and 'revenue' (numeric), sorted descending
df_sorted = df.sort_values('revenue', ascending=True)
colours = ['#DC2626' if v < df['revenue'].median() else '#2563EB' for v in df_sorted['revenue']]

fig, ax = plt.subplots(figsize=(9, 5))
bars = ax.barh(df_sorted['region'], df_sorted['revenue'], color=colours, height=0.6)
ax.bar_label(bars, fmt='£{:,.0f}', padding=4, fontsize=9)

ax.set_title("North West is the only region below the revenue median",
             fontsize=13, fontweight='bold', pad=12)
ax.set_xlabel("Revenue (£)", fontsize=10)
ax.set_xlim(0, df['revenue'].max() * 1.15)
ax.spines[['top', 'right', 'left']].set_visible(False)
ax.tick_params(left=False)
ax.grid(axis='x', alpha=0.3, linestyle='--')

plt.figtext(0.12, 0.01, "Source: orders table, YTD 2024", fontsize=8, color='grey')
plt.tight_layout()
plt.savefig("revenue_by_region.png", dpi=150, bbox_inches='tight')
plt.show()

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TEMPLATE 3: KPI CARD DASHBOARD (HTML — self-contained, shareable)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# See Step 4 for the full HTML template
```

---

## Step 4 — Self-Contained HTML Dashboard Template

```html
<!-- ambursaData Executive Dashboard Template -->
<!-- Save as dashboard.html — open in any browser, no server needed -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[Report Title] — ambursaData</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #F4F4F5; color: #0A0A0A; }
    .header { background: #0A0A0A; color: white; padding: 24px 32px; }
    .header h1 { font-size: 1.5rem; font-weight: 700; }
    .header p { font-size: 0.875rem; color: #A1A1AA; margin-top: 4px; }
    .container { max-width: 1200px; margin: 0 auto; padding: 24px 32px; }
    .kpi-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .kpi { background: white; border-radius: 8px; padding: 20px; border-left: 4px solid #2563EB; }
    .kpi.red { border-left-color: #DC2626; }
    .kpi.green { border-left-color: #16A34A; }
    .kpi-label { font-size: 0.75rem; color: #71717A; text-transform: uppercase; letter-spacing: 0.05em; }
    .kpi-value { font-size: 1.75rem; font-weight: 700; margin: 6px 0; }
    .kpi-change { font-size: 0.8rem; }
    .kpi-change.up { color: #16A34A; }
    .kpi-change.down { color: #DC2626; }
    .charts { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }
    .chart-card { background: white; border-radius: 8px; padding: 20px; }
    .chart-card h3 { font-size: 0.95rem; font-weight: 600; margin-bottom: 4px; }
    .chart-card .subtitle { font-size: 0.78rem; color: #71717A; margin-bottom: 16px; }
    .chart-full { background: white; border-radius: 8px; padding: 20px; margin-bottom: 24px; }
    .insight-box { background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 16px 20px; margin-bottom: 24px; }
    .insight-box h3 { color: #1D4ED8; font-size: 0.9rem; font-weight: 600; margin-bottom: 8px; }
    .insight-box p { font-size: 0.875rem; line-height: 1.6; }
    @media (max-width: 768px) { .charts { grid-template-columns: 1fr; } }
  </style>
</head>
<body>

<div class="header">
  <h1>[Report Title]</h1>
  <p>Period: [date range] &nbsp;|&nbsp; Prepared by ambursaData &nbsp;|&nbsp; [date]</p>
</div>

<div class="container">

  <!-- KPI Cards -->
  <div class="kpi-row">
    <div class="kpi green">
      <div class="kpi-label">Total Revenue</div>
      <div class="kpi-value">£[X]</div>
      <div class="kpi-change up">▲ [X]% vs last period</div>
    </div>
    <div class="kpi red">
      <div class="kpi-label">Active Customers</div>
      <div class="kpi-value">[X]</div>
      <div class="kpi-change down">▼ [X]% vs last period</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Avg Order Value</div>
      <div class="kpi-value">£[X]</div>
      <div class="kpi-change up">▲ [X]% vs last period</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Orders This Period</div>
      <div class="kpi-value">[X]</div>
      <div class="kpi-change">— same as last period</div>
    </div>
  </div>

  <!-- Key Insight Box -->
  <div class="insight-box">
    <h3>💡 The Most Important Finding</h3>
    <p>[State the top finding from findings.md in plain English.
        What happened, why it matters, what should be done.
        This is the first thing any executive will read.]</p>
  </div>

  <!-- Two Charts -->
  <div class="charts">
    <div class="chart-card">
      <h3>[Chart 1 Title — states the finding]</h3>
      <div class="subtitle">[One sentence of context]</div>
      <canvas id="chart1" height="250"></canvas>
    </div>
    <div class="chart-card">
      <h3>[Chart 2 Title — states the finding]</h3>
      <div class="subtitle">[One sentence of context]</div>
      <canvas id="chart2" height="250"></canvas>
    </div>
  </div>

  <!-- Full-Width Chart -->
  <div class="chart-full">
    <h3>[Chart 3 Title — states the finding]</h3>
    <div class="subtitle" style="font-size:0.78rem;color:#71717A;margin-bottom:16px;">[context]</div>
    <canvas id="chart3" height="150"></canvas>
  </div>

</div>

<script>
  // Replace with real data from query_library.md results

  // Chart 1: Bar comparison
  new Chart(document.getElementById('chart1'), {
    type: 'bar',
    data: {
      labels: ['Region A', 'Region B', 'Region C', 'Region D'],
      datasets: [{ label: 'Revenue (£)', data: [120000, 85000, 210000, 60000],
        backgroundColor: ['#2563EB','#2563EB','#16A34A','#DC2626'] }]
    },
    options: { plugins: { legend: { display: false } },
      scales: { y: { ticks: { callback: v => '£' + v.toLocaleString() } } } }
  });

  // Chart 2: Line trend
  new Chart(document.getElementById('chart2'), {
    type: 'line',
    data: {
      labels: ['Jan','Feb','Mar','Apr','May','Jun'],
      datasets: [{ label: 'Revenue', data: [80000,85000,78000,70000,65000,60000],
        borderColor: '#DC2626', backgroundColor: 'rgba(220,38,38,0.08)',
        fill: true, tension: 0.3 }]
    },
    options: { plugins: { legend: { display: false } },
      scales: { y: { ticks: { callback: v => '£' + v.toLocaleString() } } } }
  });

  // Chart 3: Full-width line
  new Chart(document.getElementById('chart3'), {
    type: 'bar',
    data: {
      labels: ['Product A','Product B','Product C','Product D','Product E'],
      datasets: [{ label: 'Revenue', data: [350000,220000,180000,90000,40000],
        backgroundColor: '#2563EB' }]
    },
    options: { indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: { x: { ticks: { callback: v => '£' + v.toLocaleString() } } } }
  });
</script>
</body>
</html>
```

---

## Output File: dashboard_spec.md

```markdown
# Dashboard Specification
Pipeline step: 4 of 6 — ambursaData
Date: [date]
Audience: [from data_brief.md]
Format: Python charts / HTML dashboard / both

---

## Chart List
| # | Chart type | Finding it shows | Title (the argument) | File |
|---|------------|------------------|----------------------|------|
| 1 |            |                  |                      |      |
| 2 |            |                  |                      |      |
| 3 |            |                  |                      |      |

## KPI Cards (for executive dashboard)
| Label | Value | Comparison | Direction |
|-------|-------|------------|-----------|
[one row per KPI]

## Dashboard Layout
[Describe the layout: what appears at the top, middle, bottom]

## Files Produced
[ ] Python charts (.png files)
[ ] HTML dashboard (dashboard.html)
[ ] Both

## Non-Technical Test Result
[Did a non-technical person understand each chart in 10 seconds? YES / NO / PENDING]

---

## Pipeline Status
Step 1 ✅ data-explorer  → data_brief.md
Step 2 ✅ sql-architect  → query_library.md
Step 3 ✅ insight-hunter → findings.md
Step 4 ✅ viz-builder    → dashboard_spec.md
Step 5 ⬜ story-weaver   → data_story.md
Step 6 ⬜ action-planner → action_plan.md
```

---

## Review Gate (MANDATORY)

After saving `dashboard_spec.md`, present this EXACTLY:

```
✅ Dashboard spec complete. Saved to dashboard_spec.md.

📋 Summary:
- Charts designed  : [N]
- KPI cards        : [N]
- Format           : [Python / HTML / both]
- Dashboard layout : [one sentence]
- Non-tech test    : [PASSED / PENDING / FAILED — reason]

Chart list:
  1. [type] — "[finding title]"
  2. [type] — "[finding title]"
  3. [type] — "[finding title]"

👉 You can:
  - Approve → say "approved" or "write the story"
  - Change a chart → say "change chart [N] to [type] because [reason]"
  - Add a chart → say "add a chart showing [question]"
  - Request HTML dashboard → say "build the HTML dashboard"

⏸️ Waiting for approval before Story Weaver runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `write the story`, `story weaver`,
`proceed`, `next`, `go`, `visuals approved`, `tell the story`
